class Footer extends HTMLElement {
    connectedCallback() {
      this.innerHTML = `
        <footer class="allfooter">
            <section class="footerContainer">
                <div class="footer-content1">
                    <div class="backtotopMobile">
                        <a href="#"><img src="../pict/icon/arrow_upward.png" width="30" height="30" alt="upward">
                            Back To Top</a>
                    </div>
                    <div class="icons item1 ">
                        <a href="#"><i class="fa fa-facebook-square" ></i></a>
                        <a href="#"><i class="fa fa-instagram" ></i></a>
                        <a href="#"><i class="fa fa-youtube-play" ></i></a>
                        <a href="#"><i class="fa fa-twitter" ></i></a>
                    </div>
                    <div class="backtotop item2">
                        <a href="#"><i class="fa fa-arrow-circle-up" style="font-size:24px;color:white;padding:2px"></i>
                            Back To Top</a>
                    </div>
                    <div class="item3">
                        <a  href="../../Tags.html">All Categories</a>
                        <a  href="../../Aboutus.html">About Us</a>
                        <a  href="#">Help</a>
                    </div>
                </div>
    
                <div class="footer-content2">
                    <p>The Discovery of Malaysia Local Delicacies</p>
                    <p style="font-weight:lighter;">&copy Nosh. Discovery Inc. or its subsidiaries and affiliates. All rights reserved.</p>
                    <br>
                    <div>
                        <a href="#">Privacy Policy</a>
                        <a href="#">Visitor Agreement</a>
                    </div>
                    <p><a href="#">Do Not Sell or Share My Personal Information</a></p>
                </div>
    
            </section>            
        </footer>
        `;
    }
  }
  
  customElements.define('footer-component', Footer);
