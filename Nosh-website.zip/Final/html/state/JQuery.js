$(function(){
    $("#header").load("Header.html"); 
    $("#footer").load("Footer.html"); 
});