$(function(){
    $("#header").load("../html/Header.html"); 
    $("#footer").load("../html/Footer.html"); 
});