Group Member 1:

Name: Loh Shin Yee
Student ID: 2203210
Course: CS
Practical Session: Friday, 1030AM - 1230PM
Practical Group: P5
Tutor: Miss Lai Siew Cheng


Group Member 2:

Name: Tam Yu You
Student ID: 2203190
Course: CS
Practical Session: Wednesday, 12PM - 2PM
Practical Group: P2
Tutor: Miss Lai Siew Cheng
