#include	<iostream>
#include	<fstream>
#include	<cstdlib>
#include	<cstdio>
#include	<ctime>
#include	"BST.h"
#include    "Student.h"

using namespace std;

bool readFile(const char*, BST*);
int menu();

BST t1;

int main() {
	type item;
	int source = 0, order = 0;
	bool veri = true;
	do {
		switch (menu())
		{
		case 1:
			readFile("student.txt", &t1);
			break;

		case 2:
			if (t1.deepestNodes() != veri)
				cout << "\nThe tree is empty\n";
			break;

		case 3:
			cout << "\nPlease choose the order of display:\n";
			cout << "1. Ascending\n2. Descending\n";
			cout << "\nEnter order: ";
			while (!(cin >> order) || (order < 1 || order > 2))
			{
				cout << "Error!!! Select (1/2) only: ";
				cin.clear();
				cin.ignore();
			}

			cout << "\nPlease choose where to display.\n1. Screen\n2. File\n";
			cout << "\nEnter source: ";
			while (!(cin >> source) || (source < 1 || source > 2))
			{
				cout << "Error!!! Select (1/2) only: ";
				cin.clear();
				cin.ignore();
			}

			if (!t1.display(order, source) == veri)
				cout << "\nTree is empty!";
			else
				cout << "\nDisplay successfully.";

			cout << "\n\n";
			break;

		case 4:
			cout << "\nWhich Sub Tree that you wish to clone: ";
			cin.clear();
			cin.ignore();
			cin >> item.id;
			t1.CloneSubTree(t1, item);
			break;

		case 5:
			cout << endl;
			if (t1.printLevelNodes() == veri)
				cout << "\nLevel nodes printed successfully!\n" << endl;
			else
				cout << "\nThe tree is empty.\n" << endl;
			break;

		case 6:
			if (t1.printPath() != veri)
				cout << "\nThe tree is empty\n" << endl;
			break;

		case 7:
			veri = false;
			break;
		}

	} while (veri);
	system("pause");
	return 0;
}

bool readFile(const char* filename, BST* t1)
{
	int count = 0;
	Student s;
	ifstream in;

	in.open(filename);

	if (!in)
	{
		cout << "\n" << filename << " does not exists." << endl;
		return false;
	}
	else
	{
		while (in)
		{
			if (in.eof())
				break;
			in.ignore(13);
			in >> s.id;
			in.ignore(7);
			in.getline(s.name, 30, '\n');
			in.ignore(10);
			in.getline(s.address, 100, '\n');
			in.ignore(6);
			in.getline(s.DOB, 20, '\n');
			in.ignore(14);
			in.getline(s.phone_no, 10, '\n');
			in.ignore(9);
			in.getline(s.course, 5, '\n');
			in.ignore(7);
			in >> s.cgpa;
			in.ignore();


			if (t1->duplicate(s.id)) // check duplicate record
			{
				cout << "\nDuplication of ID[" << s.id << "] is found!\n";
				cout << "The second record of student with id [" << s.id << "] will not be store again.\n";
			}
			else
			{
				if (!t1->insert(s))
					cout << "\nUnable to insert records with student ID: " << s.id << endl;
				count++;
			}
		}
	}
	cout << "\nThe number of student records successfully read: " << count << endl << endl;
	in.close();
	return true;
}

int menu()
{
	int choice;
	do
	{
		cout << "(1) Read data to BST\n(2) Print deepest nodes\n(3) Display student\n(4) Clone Subtree\n(5) Print Level Nodes\n(6) Print Path\n(7) Exit\n>> ";
		cin >> choice;
		if (choice < 1 || choice > 10)
		{
			cout << "\nInvalid please enter again!!!\n" << endl;
			cin.clear();
			cin.ignore(256, '\n');
		}
	} while (choice < 1 || choice > 10);

	return choice;
}