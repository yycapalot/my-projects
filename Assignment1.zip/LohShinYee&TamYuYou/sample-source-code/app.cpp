#include	<iostream>
#include 	<fstream>
#include	<string>
#include	<cstdlib>
#include    <iomanip>
#include	"List.h"
#include	"Student.h"

using namespace std;

bool CreateStuList(const char*, List*);
bool DeleteStudent(List*, char*);
bool PrintList(List, int);
bool InsertExamResult(const char*, List*);
bool PrintStatistic(List);
bool FilterStudent(List, List*, char*, int, int);
bool UpdateIDandPhone(List*);
bool FindPotentialFirstClass(List, List*, char*);
int menu();

using namespace std;

int main() {
	bool veri = true;
	int source = 0;
	char id[12];
	char course[10];
	List studentlist;
	List filteredList;
	int year, totalCredits;
	int sc;

	do {
		switch (menu())
		{
		case 1:
			if (CreateStuList("student.txt", &studentlist) == veri)
				cout << "\nStudent list is successfully inserted!!!\n\n";
			else
				cout << "\n!!! Student list cannot insert!!!\n\n";
			break;

		case 2:
			cout << "\nEnter the student ID to delete >> ";
			cin >> id;
			if (DeleteStudent(&studentlist, id) != veri)
				cout << "\nStudent not found in the list.\n\n";
			cin.clear();
			cin.ignore(256, '\n');
			break;

		case 3:
			cout << "\n1. Display to screen\n2. Display to file\n\nEnter: ";
			cin >> sc;
			if (PrintList(studentlist, sc))
				cout << "\nInformation successfully displayed!!!\n\n";
			else
				cout << "\n!!! Failed to display information!!!\n\n";
			break;

		case 4:
			if (InsertExamResult("exam.txt", &studentlist) == veri)
				cout << "\nExam result is successfully inserted!!!\n\n";
			else
				cout << "\n!!! Exam result failed to insert!!!\n\n";
			break;

		case 5:
			PrintStatistic(studentlist);
			break;

		case 6:
			cout << "Enter course code (e.g., CS): ";
			cin >> course;
			cout << "Enter year: ";
			cin >> year;
			cout << "Enter total credits earned: ";
			cin >> totalCredits;

			if (FilterStudent(studentlist, &filteredList, course, year, totalCredits) == veri)
				PrintList(filteredList, 1);
			else
				cout << "\n!!! Failed to filter student!!!\n\n";
			break;

		case 7:
			if (UpdateIDandPhone(&studentlist) == veri)
				cout << "\nStudent ID and Phone Number are UPDATED !!!\n\n";
			else
				cout << "\n!!! Failed to update ID and Phone Number !!!\n\n";
			PrintList(studentlist, 1);
			break;

		case 8:
			cout << "Enter course code (e.g., CS): ";
			cin >> course;
			if (FindPotentialFirstClass(studentlist, &filteredList, course) == veri)
				PrintList(filteredList, 1);
			else
				cout << "\nFailed to find potential first class!!!\n\n";
			cin.clear();
			cin.ignore(256, '\n');
			break;

		case 9:
			veri = false;
			break;
		}
	} while (veri);
	system("pause");
	return 0;
}

bool CreateStuList(const char* filename, List* list)
{
	char line[256];
	type* student1 = new Student;
	type* student2 = new Student;
	bool duplicate = true;
	int count = 1;

	ifstream fileread;

	fileread.open(filename);

	if (!fileread)
	{
		cout << "\n\nThe file is not open!\n" << endl;
		return false;
	}

	else
	{
		for (int i = 1; !fileread.eof(); i++)
		{
			fileread >> line;
			switch (i)
			{
			case 3:
				fileread >> student2->id;
				break;
			case 5:
				fileread >> student2->name;
				fileread.getline(line, 50);
				strcat(student2->name, line);
				break;
			case 7:
				fileread >> student2->course;
				break;
			case 10:
				fileread >> student2->phone_no;
				break;
			}

			//check the duplicate student id
			if (list->size() > 0 && i == 11) //if size of list is greater than 0 and i = 11 = end of the first student value
			{
				for (int j = 1; j <= list->size(); j++)
				{
					list->get(j, *student1);
					if (strcmp(student1->id, student2->id) == 0)
					{
						cout << "Error!!! Duplicated ID found : " << student2->id << endl;
						duplicate = false;
					}
				}
			}

			//reset the i to read other values
			if (i == 11)
			{
				i = 1;
				if (duplicate)
				{
					list->insert(*student2);
				}
				duplicate = true;
			}
		}
		return true;
	}
	fileread.close();


}

bool DeleteStudent(List* list, char* id)
{
	if (list->empty())
	{
		cout << "\n!!! The list is empty !!!\n\n" << endl;
		return false;
	}

	Node* current = list->head;
	Node* prev = nullptr;

	// Traverse the list to find the student with the given ID
	while (current != nullptr)
	{
		if (strcmp(current->item.id, id) == 0)
		{
			// If the student is found, remove the node using the remove function
			int position = 1;
			if (prev == nullptr)
			{
				// If the node to be deleted is the head node
				list->remove(position);
			}
			else
			{
				list->remove(position + 1); // Adjust position for remove function
			}
			cout << "\nStudent with ID " << id << " deleted successfully.\n";
			return true;
		}
		prev = current;
		current = current->next;
	}

	// If student not found in the list
	cout << "\nStudent with ID " << id << " not found in the list.\n";
	return false;
}

bool PrintList(List list, int source)
{
	Exam exam;

	if (list.empty())
	{
		cout << "\n!!! The list is empty !!!\n\n" << endl;
		return false;
	}

	if (source == 1)
	{
		cout << "Printing to screen:\n\n";
		for (int i = 1; i <= list.size(); i++)
		{
			type* student = new Student;
			list.get(i, *student);
			cout << "******************************************************STUDENT " << i << "******************************************************\n";
			student->print(cout);

			if (student->exam_cnt == 0)
			{
				cout << "\nTHIS STUDENT HAVEN�T TAKEN ANY EXAM YET\n\n";
			}
			else
			{
				cout << "\n--------------------------------------------------PAST EXAM RESULT:--------------------------------------------------\n\n";
				for (int j = 0; j < student->exam_cnt; j++)
				{
					exam = student->exam[j];
					cout << exam.printTrimester() << " " << exam.year << " Exam Results:\n\n";
					cout << exam.numOfSubjects << " subjects taken.\n";
					cout << "_____________________________________________________________________________________________________________________\n";
					cout << "Subject Code\t\tSubject Name\t\t\t\t\t\t\tCredit Hours\t\t Grade\t\t  Grade Point\n";
					cout << "_____________________________________________________________________________________________________________________\n";

					for (int k = 0; k < exam.numOfSubjects; k++)
					{
						Subject subject = exam.sub[k];
						cout << subject.subject_code << "\t\t" << subject.subject_name << "\t\t\t\t" << subject.credit_hours << "\t   " << subject.getGrade() << "\t" << fixed << setprecision(5) << subject.getGradePoint() << endl;
					}

					cout << "\nGPA: " << fixed << setprecision(5) << exam.gpa << "\n\n";
				}
			}
			cout << endl;
		}
	}
	else if (source == 2)
	{
		ofstream outFile("student_result.txt");

		if (!outFile)
		{
			cerr << "Error opening the file." << endl;
			return false;
		}

		outFile << "Printing to file:\n";

		for (int i = 1; i <= list.size(); i++)
		{
			type* student = new Student;
			list.get(i, *student);
			student->print(outFile);

			if (student->exam_cnt == 0)
			{
				outFile << "\nTHIS STUDENT HAVEN�T TAKEN ANY EXAM YET\n\n";
			}
			else
			{
				outFile << "\n--------------------------------------------------PAST EXAM RESULT:--------------------------------------------------\n\n";
				for (int j = 0; j < student->exam_cnt; j++)
				{
					exam = student->exam[j];
					outFile << exam.printTrimester() << " " << exam.year << " Exam Results:\n\n";
					outFile << exam.numOfSubjects << " subjects taken.\n";
					outFile << "_____________________________________________________________________________________________________________________\n";
					outFile << "Subject Code\t\tSubject Name\t\t\t\t\t\t\tCredit Hours\t\t Grade\t\ts  Grade Point\n";
					outFile << "_____________________________________________________________________________________________________________________\n";

					for (int k = 0; k < exam.numOfSubjects; k++)
					{
						Subject subject = exam.sub[k];
						outFile << subject.subject_code << "\t\t" << subject.subject_name << "\t\t\t\t" << subject.credit_hours << "\t   " << subject.getGrade() << "\t" << fixed << setprecision(5) << subject.getGradePoint() << endl;
					}

					outFile << "\nGPA: " << fixed << setprecision(5) << exam.gpa;
				}
			}
			outFile << endl;
		}

		outFile.close();
	}
	else
	{
		cout << "\nInvalid source specified.\n";
		return false;
	}

	return true;
}

bool InsertExamResult(const char* filename, List* list)
{
	ifstream readExamFile;

	readExamFile.open(filename);

	if (!readExamFile)
	{
		cout << "\n\nThe file is not open!\n" << endl;
		return false;
	}

	while (!readExamFile.eof())
	{
		type* student = new Student;
		Exam exam;
		int gpaCredits = 0;
		double gpaSum = 0;

		readExamFile >> student->id >> exam.trimester >> exam.year >> exam.numOfSubjects;

		for (int i = 0; i < exam.numOfSubjects; ++i)
		{
			readExamFile >> exam.sub[i].subject_code >> exam.sub[i].subject_name >> exam.sub[i].credit_hours >> exam.sub[i].marks;
			gpaCredits += exam.sub[i].credit_hours;
		}

		// calculate gpa
		for (int g = 0; g < exam.numOfSubjects; g++)
		{
			gpaSum = gpaSum + exam.sub[g].getGradePoint() * exam.sub[g].credit_hours;
		}

		exam.gpa = gpaSum / (double)gpaCredits;

		// Find the student in the list and store exam struct if ID matches
		for (Node* current = list->head; current != nullptr; current = current->next)
		{
			type* currentStudent = &(current->item);
			if (strcmp(student->id, currentStudent->id) == 0)
			{
				currentStudent->totalCreditsEarned += gpaCredits;
				// ID matches, store exam struct for this student
				if (currentStudent->exam_cnt < 10) // Ensure we don't exceed the limit
				{
					currentStudent->exam[currentStudent->exam_cnt] = exam;
					currentStudent->exam_cnt++;

					break; // Exit the loop once the exam is stored
				}
				else
				{
					cout << "Student " << currentStudent->id << " already has 10 exam results stored." << endl;
					break; // Exit loop since we can't store more exams for this student
				}
			}
		}
	}

	readExamFile.close();

	// Calculate current cgpa
	for (Node* current = list->head; current != nullptr; current = current->next)
	{
		type* currentStudent = &(current->item);
		double cgpaSum = 0;
		Exam temp;
		int total_credits_cgpa = 0;

		if (current->item.exam_cnt == 0)
		{
			cout << "\n\nNo exam result yet.\n";
			return false;
		}

		else
		{
			current->item.totalCreditsEarned = 0;
			for (int i = 0; i < current->item.exam_cnt; i++)
			{

				total_credits_cgpa = 0;
				for (int j = 0; j < current->item.exam[i].numOfSubjects; j++)
				{
					total_credits_cgpa = total_credits_cgpa + current->item.exam[i].sub[j].credit_hours;
				}

				// Calculate total points
				cgpaSum = cgpaSum + (current->item.exam[i].gpa * total_credits_cgpa);
				current->item.totalCreditsEarned = current->item.totalCreditsEarned + total_credits_cgpa;

			}

			current->item.current_cgpa = cgpaSum / current->item.totalCreditsEarned;
		}
	}
	return true;
}

bool PrintStatistic(List list)
{
	Node* cur = list.head;
	Exam exam;

	struct CourseCount
	{
		char course[3];
		int count;
	};

	int totalStud = 0, numC = 0, totalsub = 0, totalexam = 0;
	double totalcgpa = 0, totalcre = 0;
	bool Exists = false;

	CourseCount courseCounts[100]{};

	if (list.empty())
	{
		cout << "\n!!! The list is empty !!!\n\n" << endl;
		return false;
	}

	if (cur->item.totalCreditsEarned == 0)
	{
		cout << "\n!!! Please insert student exam result !!!\n\n";
		return false;
	}

	while (cur != NULL)
	{
		int exam_cnt = cur->item.exam_cnt;
		totalStud++;

		for (int i = 0; i < numC; ++i) //loop for the second course as numC++
		{
			if (strcmp(courseCounts[i].course, cur->item.course) == 0) //Compare the course to the cur->next
			{
				courseCounts[i].count++;
				Exists = true;
				break;
			}
		}

		if (Exists == false)
		{
			strcpy(courseCounts[numC].course, cur->item.course); //assign current course to the coursecounts.course
			courseCounts[numC].count = 1; //assume there is one course only
			numC++;
		}

		totalcre += cur->item.totalCreditsEarned;
		totalcgpa += cur->item.current_cgpa;
		totalexam += exam_cnt;
		for (int i = 0; i < exam_cnt; i++)
		{
			totalsub += cur->item.exam[i].numOfSubjects;
		}

		cur = cur->next;
	}

	cout << "\nTotal Students: " << totalStud << std::endl;
	for (int i = 0; i < numC; ++i) {
		cout << right << setw(4) << courseCounts[i].course << " Students - " << courseCounts[i].count << endl;
	}
	cout << endl;
	cout << "Average CGPA: " << totalcgpa / totalStud << endl;
	cout << fixed << "Average Subjects Taken per Semester: " << setprecision(2) << totalsub / totalexam << endl;
	cout << fixed << "Average Credits Earned per Semester: " << fixed << setprecision(2) << totalcre / totalexam << endl;

	cout << endl << endl;
	return true;
}

bool FilterStudent(List list1, List* list2, char* course, int year, int totalcredit)
{
	while (!list2->empty())
	{
		list2->remove(1);  // Remove the first node in each iteration
	}

	if (list1.empty() || list2->size() > 0)
	{
		cout << "\nInvalid operation: list1 is empty or list2 is not empty.\n" << endl;
		return false;
	}

	// Convert user input course to uppercase
	for (int i = 0; course[i] != '\0'; i++)
	{
		course[i] = toupper(course[i]);
	}

	for (int i = 1; i <= list1.size(); i++)
	{
		type* student = new Student;
		list1.get(i, *student);

		// Extracting year from student ID
		char yearEnrolled[3];
		strncpy(yearEnrolled, student->id, 2);
		yearEnrolled[2] = '\0';
		int studentYear = atoi(yearEnrolled) + 2000;

		// Convert student course to uppercase for comparison
		char studentCourse[10];
		strcpy(studentCourse, student->course);
		for (int j = 0; studentCourse[j] != '\0'; j++)
		{
			studentCourse[j] = toupper(studentCourse[j]);
		}

		if (strcmp(student->course, course) == 0 && studentYear == year && student->totalCreditsEarned >= totalcredit)
		{
			// Student meets all conditions, insert into list2
			list2->insert(*student);
		}
	}

	return true;
}

bool UpdateIDandPhone(List* list)
{
	char id[12] = { 'B','\0' };
	char* dash;
	char odd[12] = { '0','1','\0' };
	char even[12] = { '0','2','\0' };
	int i = 1;
	Node* cur;
	if (list->empty()) {

		cout << "\n!!! List is empty !!!\n\n";
		return false;
	}

	cur = list->head;

	while (cur != NULL)
	{
		strcat(id, cur->item.course);
		strcat(id, cur->item.id);
		strcpy(cur->item.id, id);

		id[1] = '\0';

		dash = strchr(cur->item.phone_no, '-');  //find the character of '-'

		if (dash)
		{
			strcpy(dash, dash + 1);
		}

		if (cur->item.phone_no[0] % 2 == 1)
		{
			strcat(odd, cur->item.phone_no);
			strcpy(cur->item.phone_no, odd);
			odd[i++] = '\0';
		}
		else
		{
			strcat(even, cur->item.phone_no);
			strcpy(cur->item.phone_no, even);
			even[i++] = '\0';
		}
		cur = cur->next;

	}
	return true;
}

bool FindPotentialFirstClass(List list1, List* list2, char* course)
{
	while (!list2->empty())
	{
		list2->remove(1);  // Remove the first node in each iteration
	}

	if (list1.empty() || list2->size() > 0)
	{
		cout << "\nInvalid operation: list1 is empty or list2 is not empty.\n" << endl;
		return false;
	}

	// Convert user input course to uppercase
	for (int i = 0; course[i] != '\0'; i++)
	{
		course[i] = toupper(course[i]);
	}

	for (int i = 1; i <= list1.size(); i++)
	{
		type* student = new Student;
		list1.get(i, *student);

		if (strcmp(student->course, course) == 0)
		{
			int highGpaCount = 0;
			bool hasLowGpa = false;

			for (int j = 0; j < student->exam_cnt; j++)
			{
				int creditHr = 0;
				// calculate credit hour
				for (int n = 0; n < student->exam[j].numOfSubjects; ++n)
				{
					creditHr += student->exam[j].sub[n].credit_hours;
				}

				if (student->exam[j].gpa >= 3.75 && creditHr >= 12)
				{
					highGpaCount++;
				}
				else if (student->exam[j].gpa < 3.5)
				{
					hasLowGpa = true;
					break;
				}
			}

			if (highGpaCount >= 3 && !hasLowGpa)
			{
				// Student meets the criteria, insert into list2
				list2->insert(*student);
			}
		}
	}

	if (list2->empty())
	{
		cout << "\nThere is no student in " << course << " that has potential to get first class.\n\n";
	}

	return true;
}

int menu()
{
	int select;
	do {
		cout << "1. Create student list\n2. Delete Student\n3. Print student list\n4. Insert exam result\n5. Print exam Statistic\n6. Filter student\n7. Update student's ID and Phone\n8. Find Potential First Class Student\n9. Exit\nPlease enter your choice >> ";
		cin >> select;


		if (select < 1 || select>10)
		{
			cout << "\nInvalid please enter again!!!\n" << endl;
			cin.clear();
			cin.ignore(256, '\n');
		}
	} while (select < 1 || select>10);

	return select;

}