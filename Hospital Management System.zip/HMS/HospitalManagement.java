import javafx.application.Application;

public class HospitalManagement {
	public static void main(String[] args) {;
		ui ui = new ui();
		Doctor[] doctor = new Doctor[25];
		Patient[] patient = new Patient[100];
		Lab[] lab = new Lab[20];
		Facility[] facility = new Facility[20];
		Medicine[] medicine = new Medicine[100];
		Staff[] staff = new Staff[100];
		
		for(int i=0; i<3; i++) {
			doctor[i] = new Doctor();
			patient[i] = new Patient();
			lab[i] = new Lab();
			facility[i] = new Facility();
			medicine[i] = new Medicine();
			staff[i] = new Staff();
			if(i==0) {
				staff[i].newStaff("A001", "Benedict", "M", "CEO of Hospital", 20000);
				doctor[i].newDoctor("847", "Chai Yau Yuen", "Nutritionist", "10.00am - 6.00pm", "BSc (Hons) in Nutrition ",101);
				patient[i].newPatient("24A001", "Lim Ko Peh","M", "Diabetes II", "Observation", 56);
				medicine[i].newMedicine("Metformin", "Lek S. A", "23/08/2028", 5, 1000);
				lab[i].newLab("Research Lab", 155500);
				facility[i].newFacility("Birth Centers");
			}
			else if(i==1) {
				staff[i].newStaff("A002", "Christine", "F", "Secretary of CEO", 10000);
				doctor[i].newDoctor("199", "Tam Yu You", "Nephrologists", "10.00am - 6.00pm", "MBBS",206);
				patient[i].newPatient("24A001", "Bo Ho Lim","M", "Lung Cancer Stage II", "Inpatient", 25);
				medicine[i].newMedicine("Docetaxel", "Sanofi-Aventis", "10/05/2030", 145, 1000);
				lab[i].newLab("Clinical Lab", 94065);
				facility[i].newFacility("Blood Banks");
			}
			else if(i==2) {
				staff[i].newStaff("A003", "Raymond", "M", "Managing Director", 15000);
				doctor[i].newDoctor("154", "Cindy Wong Kah Mei", "Neurosurgeon", "10.00am - 6.00pm", "MBBS",170);
				patient[i].newPatient("24A001", "Lim Teh Peng","M", "Covid-19", "Outpatient", 35);
				medicine[i].newMedicine("Irinotecan.", "CAMPTOSAR", "22/02/2025", 180, 1000);
				lab[i].newLab("Blood Test Lab", 51132);
				facility[i].newFacility("Clinical and medical officers");
			}
		}
		
		ui.setStaffs(staff);
		ui.setDoctors(doctor);
		ui.setPatients(patient);
		ui.setMedicines(medicine);
		ui.setLabs(lab);
		ui.setFacilities(facility);	
		
		Application.launch(ui.class);
	
	}
}
