
public class Facility {
	private String facility;
	
	public void newFacility(String facility) {
		this.facility = facility;
	}
	
	public void showFacility() {
		System.out.println(facility);
	}
	
	public String getFacility() {
		return facility;
	}
}
