
public class Patient extends Individual{
	private String disease, admitStatus;
	private int age;
	
	public void newPatient(String id, String name, String sex, String disease, String admitStatus, int age) {
		super.setId(id);
		super.setName(name);
		super.setSex(sex);
		this.disease = disease;
		this.admitStatus = admitStatus;
		this.age = age;
	}
	
	public String getDisease() {
		return disease;
	}

	public String getAdmitStatus() {
		return admitStatus;
	}

	public int getAge() {
		return age;
	}

	public void showPatientInfo() {
		System.out.println(super.getId()+"\t"+super.getName()+"\t"+disease+"\t"+super.getSex()+"\t"+admitStatus+"\t"+age);
	}
}
