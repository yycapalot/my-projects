
public class Medicine{
	private String name, manufacturer, expiryDate;
	private int cost, count;
	
	public void newMedicine(String name, String manufacturer, String expiryDate, int cost, int count) {
		this.name = name;
		this.manufacturer = manufacturer;
		this.expiryDate = expiryDate;
		this.cost = cost;
		this.count = count;
	}
	
	public void findMedicine() {
		System.out.println(name+"\t"+manufacturer+"\t"+expiryDate+"\t"+cost+"\t"+count);
	}
	
	public String getName() {
		return name;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public int getCost() {
		return cost;
	}

	public int getCount() {
		return count;
	}
}
