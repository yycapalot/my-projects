
public class Test {
	public static void main(String[] args) {
		String [] xStrings = new String[2];
		xStrings[0] = "1";
		xStrings[1] = "2";
		xStrings[2] = "3";
		xStrings[3] = "4";
		
		for(int i=0; xStrings[i] != null && i<xStrings.length-1; i++) {
			if(xStrings[i+1] == null) {
				xStrings[i+1] = "6";
			}
		}

		for(int i=0; i<xStrings.length; i++) {
			System.out.println(xStrings[i]);
		}
	}
}

