
public class Staff extends Individual{
	private String designation;
	private int salary;
	
	public void newStaff(String id, String name, String sex, String designation, int salary) {
		super.setId(id);
		super.setName(name);
		super.setSex(sex);
		this.designation = designation;
		this.salary = salary;
	}
	
	public void showStaffInfo() {
		System.out.println(super.getId()+"\t"+super.getName()+"\t"+designation+"\t"+super.getSex()+"\t"+salary);
	}

	public String getDesignation() {
		return designation;
	}

	public int getSalary() {
		return salary;
	}
	
	
}
