
public class Doctor extends Individual{
	private String specialist, workTime, qualification;
	private int roomNo;
	
	public void newDoctor(String id, String name, String specialist, String workTime, String qualification, int roomNo) {
		super.setId(id);
		super.setName(name);
		this.specialist = specialist;
		this.workTime = workTime;
		this.qualification = qualification;
		this.roomNo = roomNo;
	}
	
	public void showDoctorInfo() {
		System.out.println(super.getId()+"\t"+super.getName()+"\t"+specialist+"\t"+workTime+"\t"+qualification+"\t"+roomNo);
	}

	public String getSpecialist() {
		return specialist;
	}

	public String getWorkTime() {
		return workTime;
	}

	public String getQualification() {
		return qualification;
	}

	public int getRoomNo() {
		return roomNo;
	}
}
