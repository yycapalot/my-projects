import java.util.Date;
import java.text.SimpleDateFormat;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ui_1 extends Application{
	private static Staff[] staff;
	private static Doctor[] doctor;
	private static Patient[] patient;
	private static Medicine[] medicine;
	private static Lab[] lab;
	private static Facility[] facility;
	private TextField[] columnFill;
	
	
	@Override
	public void start(Stage primaryStage) {	
		Text[] staffText = {new Text("Id"), new Text("Name"), new Text("Sex"),
	 						new Text("Designation"), new Text("Salary")};
		Text[] doctorText = {new Text("Id"), new Text("Name"), new Text("Specialist"),
	 			 			 new Text("Working Hours"), new Text("Qualification"),
	 			 			 new Text("Room Number"),};
		Text[] patientText = {new Text("Id"), new Text("Name"), new Text("Sex"),
	 			 			  new Text("Disease"), new Text("Admit Status"),
	 			 			  new Text("Age")};
		Text[] medicineText = {new Text("Name"), new Text("Manufacturer"), new Text("Expiry Date"),
	 			   			   new Text("Cost per cap"), new Text("Count")};
		Text[] labText = {new Text("Lab"), new Text("Cost")};
		Text[] facilityText = {new Text("Facility")};
		
		Text[][] collectionText = {staffText, doctorText, patientText, medicineText, labText, facilityText};
		int [][] exceptionColumnIndex = {{4},{5},{5},{3,4},{1},{-1}};
		
		String[] comboBoxText = {"Staff", "Doctor", "Patient", "Medicine", "Lab", "Facility"};
		
	//Top text
		HBox titleBox = new HBox();
		titleBox.setStyle("-fx-border-style: hidden hidden solid hidden; -fx-border-width: 3;");
		Text title = new Text("Hospital Management System");
		title.setFont(Font.font("Montserrat",FontWeight.BOLD,FontPosture.ITALIC,25));
		titleBox.setPadding(new Insets(20));
		titleBox.getChildren().add(title);
		titleBox.setAlignment(Pos.CENTER);
		titleBox.setMaxWidth(Double.MAX_VALUE);
		
	//right bottom time
		HBox timeBox = new HBox();
		timeBox.setAlignment(Pos.CENTER);
		timeBox.setPadding(new Insets(10));
		timeBox.setStyle("-fx-background-color: linear-gradient(to right, #7698cc, #81a6d9, #8db4e5, #99c3f2, #a6d1ff);");
		Text timeText = new Text();
		timeText.setFont(Font.font("Montserrat",FontPosture.ITALIC,18));
		timeText.setStyle("-fx-fill: black; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.7), 10, 0.0, 3, 3);");
		timeBox.getChildren().add(timeText);
		
		Thread thread = new Thread(()->{
			SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy hh:mm:ss a");
			while(true) {
				try {
					Thread.sleep(5);
				}catch (Exception e) {
					System.out.println(e);
				}
				final String time = sdf.format(new Date());
				timeText.setText(time);
			}
		});
		thread.start();
		
	//Exit button
		Button btnExit = new Button("Exit");
		btnExit.setFont(Font.font("Arial",14));
		btnExit.setStyle(
			    "-fx-background-color: red; " +
			    "-fx-text-fill: white; " +
			    "-fx-font-weight: bold; " +
			    "-fx-background-radius: 20; " +
			    "-fx-border-color: transparent; " + 
			    "-fx-border-radius: 20; " +  
			    "-fx-border-width: 2;" 
			);
		
		btnExit.setOnMouseEntered(e -> {
		    btnExit.setStyle(
		        "-fx-background-color: red; " +
		        "-fx-text-fill: white; " +
		        "-fx-font-weight: bold; " +
		        "-fx-background-radius: 20; " +
		        "-fx-border-color: white; " + 
		        "-fx-border-radius: 20; " +
		        "-fx-border-width: 2;"
		    );
		});
		
		btnExit.setOnMouseExited(e -> {
		    btnExit.setStyle(
		        "-fx-background-color: red; " +
		        "-fx-text-fill: white; " +
		        "-fx-font-weight: bold; " +
		        "-fx-background-radius: 20; " +
		        "-fx-border-color: transparent; " + 
		        "-fx-border-radius: 20; " +
		        "-fx-border-width: 2;"
		    );
		});
		StackPane exitPane = new StackPane(btnExit);
		exitPane.setPrefWidth(255);
		exitPane.setAlignment(Pos.CENTER_RIGHT);
		
	//View Button
		Button btnView = new Button("View List");
		btnView.setFont(Font.font("Arial",14));
		btnView.setStyle(
			    "-fx-background-color: #2E8B57; " +
			    "-fx-text-fill: white; " +
			    "-fx-font-weight: bold; " +
			    "-fx-background-radius: 20; " +
			    "-fx-border-color: transparent; " + 
			    "-fx-border-radius: 20; " +  
			    "-fx-border-width: 2;" 
			);
		
		btnView.setOnMouseEntered(e -> {
		    btnView.setStyle(
		        "-fx-background-color: #2E8B57; " +
		        "-fx-text-fill: white; " +
		        "-fx-font-weight: bold; " +
		        "-fx-background-radius: 20; " +
		        "-fx-border-color: white; " + 
		        "-fx-border-radius: 20; " +
		        "-fx-border-width: 2;"
		    );
		});
		
		btnView.setOnMouseExited(e -> {
		    btnView.setStyle(
		        "-fx-background-color: #2E8B57; " +
		        "-fx-text-fill: white; " +
		        "-fx-font-weight: bold; " +
		        "-fx-background-radius: 20; " +
		        "-fx-border-color: transparent; " + 
		        "-fx-border-radius: 20; " +
		        "-fx-border-width: 2;"
		    );
		});
		
		
	//comboBox
		ComboBox<String> comboBox = new ComboBox<String>(FXCollections.observableArrayList(comboBoxText)); 
		comboBox.getSelectionModel().selectFirst();
		comboBox.setPrefWidth(140);
		comboBox.setStyle("-fx-background-color: white; -fx-text-fill: white; " + "-fx-border-color: #87CEFA; -fx-border-radius: 10; -fx-background-radius: 10;");

		
	//HBox for Center BorderPane Top
		HBox centerBPTopBox = new HBox(5);
		centerBPTopBox.getChildren().addAll(comboBox,btnView, exitPane);
		centerBPTopBox.setAlignment(Pos.CENTER);
		
	//Center Selection Pane
		BorderPane centerBPane = new BorderPane();
		centerBPane.setStyle("-fx-background-color: linear-gradient(to right, #7698cc, #81a6d9, #8db4e5, #99c3f2, #a6d1ff);");
		centerBPane.setPadding(new Insets(0,80,0,80));
		centerBPane.setTop(centerBPTopBox);
		
	//insert button
		Button btnInsert = new Button("Insert");
		btnInsert.setFont(Font.font("Arial",14));
		btnInsert.setStyle(
			    "-fx-background-color: white; " +
			    "-fx-text-fill: black; " +
			    "-fx-font-weight: bold; " +
			    "-fx-background-radius: 20; " +
			    "-fx-border-color: transparent; " + 
			    "-fx-border-radius: 20; " +  
			    "-fx-border-width: 2;" 
			);
		
		btnInsert.setOnMouseEntered(e -> {
			btnInsert.setStyle(
		        "-fx-background-color: white; " +
		        "-fx-text-fill: black; " +
		        "-fx-font-weight: bold; " +
		        "-fx-background-radius: 20; " +
		        "-fx-border-color: black; " + 
		        "-fx-border-radius: 20; " +
		        "-fx-border-width: 2;"
		    );
		});
		
		btnInsert.setOnMouseExited(e -> {
			btnInsert.setStyle(
		        "-fx-background-color: white; " +
		        "-fx-text-fill: black; " +
		        "-fx-font-weight: bold; " +
		        "-fx-background-radius: 20; " +
		        "-fx-border-color: transparent; " + 
		        "-fx-border-radius: 20; " +
		        "-fx-border-width: 2;"
		    );
		});
		StackPane btnInsertPane = new StackPane(btnInsert);
		btnInsertPane.setPrefWidth(82);
		btnInsertPane.setAlignment(Pos.CENTER_RIGHT);
		
	//whole pane
		BorderPane bPane = new BorderPane();
		bPane.setTop(titleBox);
		bPane.setCenter(centerBPane);
		bPane.setBottom(timeBox);
		
		Scene scene = new Scene(bPane,1000 ,600);
		primaryStage.setTitle("Hospital Management System");
		primaryStage.setScene(scene);
		scene.getRoot().setStyle("-fx-padding: 0;");
		primaryStage.show();
		
	//Error Message
		StackPane errorPane = new StackPane();
		errorPane.setAlignment(Pos.CENTER_LEFT);
		errorPane.setPrefWidth(400);
		Text error = new Text();
		error.setFill(Color.RED);;
		errorPane.getChildren().add(error);
	
	//HBox for error message and insert button bottom
		HBox Msg_btnInset= new HBox(errorPane,btnInsertPane);
		
		
		centerBPane.setCenter(userInsert(collectionText[0],Msg_btnInset));
		dataInsert(btnInsert, 0, error, collectionText, centerBPane, exceptionColumnIndex);
	//Event Handling
		comboBox.setOnAction(e ->{
			int index = comboBox.getItems().indexOf(comboBox.getValue());
			centerBPane.setCenter(userInsert(collectionText[index],Msg_btnInset));
			dataInsert(btnInsert, index, error, collectionText, centerBPane, exceptionColumnIndex);
			error.setText("");
			btnView.setText("View List");
			centerBPane.setBottom(null);
		});
		
		btnView.setOnAction(e->{
			int index = comboBox.getItems().indexOf(comboBox.getValue());
			Text [][] dataText = dataUpdate(index);
			showList(collectionText[index], dataText, centerBPane);
		});
		
		btnExit.setOnAction(e->{
			 Stage stage = (Stage) btnExit.getScene().getWindow();
			 stage.close();
		});
	}
	
	private VBox userInsert(Text[]columnLabel, HBox btnInsertPane) {

		//Label and TextField
		columnFill = new TextField[columnLabel.length];
		StackPane[] seperator = new StackPane[columnLabel.length];
		StackPane[] paneForText = new StackPane[columnLabel.length];
		HBox [] columnHBox = new HBox[columnLabel.length+1];
		VBox columnVBox = new VBox(15);
		columnVBox.setPadding(new Insets(10));
		
		for(int i=0; i<columnLabel.length; i++) {
			columnLabel[i].setFont(Font.font("Montserrat",18));
			Text colon = new Text(":");
			colon.setFont(Font.font("Arial",FontWeight.BOLD,17));
			seperator[i] = new StackPane(colon);
			seperator[i].setAlignment(Pos.CENTER);
			columnFill[i] = new TextField();
			columnFill[i].setPrefWidth(350);
			columnFill[i].setStyle("-fx-border-color: blue");
			
			paneForText[i] = new StackPane(columnLabel[i]);
			paneForText[i].setPadding(new Insets(0,0,3,0));
			paneForText[i].setPrefWidth(125);
			paneForText[i].setAlignment(Pos.CENTER_LEFT);
			columnHBox[i] = new HBox();
			
			columnHBox[i].setAlignment(Pos.CENTER);
			columnHBox[i].getChildren().addAll(paneForText[i],seperator[i],columnFill[i]);
			columnVBox.getChildren().add(columnHBox[i]);
		}
		
		// Insert Button
		columnHBox[columnLabel.length] = new HBox();
		columnHBox[columnLabel.length].setAlignment(Pos.CENTER);
		columnHBox[columnLabel.length].getChildren().add(btnInsertPane);
		columnVBox.getChildren().add(columnHBox[columnLabel.length]);
		
		return columnVBox;
	}

	private boolean userCheck(Button btnInsert, int[][] exceptionIndex, Text error, int index) {
		boolean status = true;
		for(int i=0; i<columnFill.length; i++) {
			if(columnFill[i].getText().equals("")) {
				status = false;
				error.setText(String.format("Incorrect value"));
				columnFill[i].setStyle("-fx-border-color: red");
			}
			else if(!columnFill[i].getText().equals("")) {
				columnFill[i].setStyle("-fx-border-color: blue");
			}
		}
		
		for(int j=0; j<exceptionIndex[index].length; j++) {
			if(exceptionIndex[index][j] == -1) {
				continue;
			}
			
			try {
				Integer.parseInt(columnFill[exceptionIndex[index][j]].getText());
			}
			catch (NumberFormatException ex) {
				status = false;
				error.setFill(Color.RED);
				error.setText(String.format("Incorrect value"));
				columnFill[exceptionIndex[index][j]].setStyle("-fx-border-color: red");
			}
			
		}

		return status;
	}

	private void dataInsert(Button btnInsert, int index, Text error, Text[][] collectionText, BorderPane centerBPane, int[][] exceptionIndex) {
		btnInsert.setOnAction(e->{
			if(userCheck(btnInsert, exceptionIndex, error, index)) {				
				if(index == 0) {
					updateStaff(columnFill);
				}
				else if(index == 1) {
					updateDoctor(columnFill);
				}
				else if(index == 2) {
					updatePatient(columnFill);
				}
				else if(index == 3) {
					updateMedicine(columnFill);
				}
				else if(index == 4) {
					updateLab(columnFill);
				}			
				else if(index == 5) {
					updateFacility(columnFill);
				}				
				
				for(int i=0; i<columnFill.length; i++) {
					columnFill[i].setText("");
					columnFill[i].setStyle("-fx-border-color: blue");
				}
				error.setFill(Color.BLUE);
				error.setText("Data successfully insert.");
				
				Text[][] dataText = dataUpdate(index);
				if(centerBPane.getBottom() != null) {
					showList(collectionText[index], dataText, centerBPane);
				}
			}
		});
	}
	
	private void showList(Text[] texts, Text[][] cellLabel,BorderPane centerBPane) {
		Text[] headerLabel = new Text[texts.length];
		for(int i=0; i<texts.length; i++) {
			headerLabel[i] = new Text(texts[i].getText());
			headerLabel[i].setFont(Font.font("Arial",FontWeight.BOLD,17));
		}
		StackPane[] header = new StackPane[headerLabel.length];
		GridPane gPane = new GridPane();
		
		gPane.setAlignment(Pos.CENTER);
		gPane.setStyle("-fx-border-color: black; -fx-border-width:2;");
		gPane.setHgap(30);
		gPane.setVgap(5);
		
		for(int i=0; i<headerLabel.length; i++) {
			header[i] = new StackPane();
			header[i].setAlignment(Pos.CENTER_LEFT);
			header[i].setStyle("-fx-border-style: hidden hidden solid hidden");
			header[i].getChildren().add(headerLabel[i]);
			gPane.add(header[i],i,0);
		}
		
		int dataAmount =0;
		for(int i=0; i<cellLabel.length; i++) {
			if(cellLabel[i][0] == null) {
				break;
			}
			dataAmount++;
		}
		
		for(int i=0; i<dataAmount; i++) {
			for(int j=0; j<cellLabel[i].length; j++) {
				cellLabel[i][j].setFont(Font.font("Arial",FontWeight.LIGHT,15));
				gPane.add(cellLabel[i][j], j, i+1);
			}
		}

		centerBPane.setBottom(gPane);
	}
	
	private Text[][] dataUpdate(int index) {
		Text[][] dataText = null;
		if(index == 0) {
			dataText = new Text[staff.length][columnFill.length];
			for(int i=0; staff[i] != null; i++) {
				dataText[i][0] = new Text(staff[i].getId());
				dataText[i][1] = new Text(staff[i].getName());
				dataText[i][2] = new Text(staff[i].getSex());
				dataText[i][3] = new Text(staff[i].getDesignation());
				dataText[i][4] = new Text(String.format("%s",staff[i].getSalary()));
			}
		}
		else if(index == 1) {
			dataText = new Text[doctor.length][columnFill.length];
			for(int i=0; doctor[i] != null; i++) {
				dataText[i][0] = new Text(doctor[i].getId());
				dataText[i][1] = new Text(doctor[i].getName());
				dataText[i][2] = new Text(doctor[i].getSpecialist());
				dataText[i][3] = new Text(doctor[i].getWorkTime());
				dataText[i][4] = new Text(doctor[i].getQualification());
				dataText[i][5] = new Text(String.format("%s",doctor[i].getRoomNo()));
			}
		}
		else if(index == 2) {
			dataText = new Text[patient.length][columnFill.length];
			for(int i=0; patient[i] != null; i++) {
				dataText[i][0] = new Text(patient[i].getId());
				dataText[i][1] = new Text(patient[i].getName());
				dataText[i][2] = new Text(patient[i].getSex());
				dataText[i][3] = new Text(patient[i].getDisease());
				dataText[i][4] = new Text(patient[i].getAdmitStatus());
				dataText[i][5] = new Text(String.format("%s",patient[i].getAge()));
			}
		}
		else if(index == 3) {
			dataText = new Text[medicine.length][columnFill.length];
			for(int i=0; medicine[i] != null; i++) {
				dataText[i][0] = new Text(medicine[i].getName());
				dataText[i][1] = new Text(medicine[i].getManufacturer());
				dataText[i][2] = new Text(medicine[i].getExpiryDate());
				dataText[i][3] = new Text(String.format("%s",medicine[i].getCost()));
				dataText[i][4] = new Text(String.format("%s",medicine[i].getCount()));
			}
		}
		else if(index == 4) {
			dataText = new Text[lab.length][columnFill.length];
			for(int i=0; lab[i] != null; i++) {
				dataText[i][0] = new Text(lab[i].getLab());
				dataText[i][1] = new Text(String.format("%s",lab[i].getCost()));
			}
		}
		else if(index == 5) {
			dataText = new Text[facility.length][columnFill.length];
			for(int i=0; facility[i] != null; i++) {
				dataText[i][0] = new Text(facility[i].getFacility());
			}
		}
		
		return dataText;
	}
	
	
	private void updateStaff(TextField[] arr) {
		for(int i=0; i<staff.length; i++) {
			if(staff[i] == null ) {
				staff[i] = new Staff();
				staff[i].newStaff(arr[0].getText(), arr[1].getText(), arr[2].getText(), arr[3].getText(), Integer.parseInt(arr[4].getText()));
				break;
			}	
		}
	}
	
	private void updateDoctor(TextField[] arr) {
		for(int i=0; i<doctor.length; i++) {
			if(doctor[i] == null ) {
				doctor[i] = new Doctor();
				doctor[i].newDoctor(arr[0].getText(), arr[1].getText(), arr[2].getText(), arr[3].getText(), arr[4].getText(), Integer.parseInt(arr[5].getText()));
				break;
			}
		}
	}
	
	private void updatePatient(TextField[] arr) {
		for(int i=0; i<patient.length; i++) {
			if(patient[i] == null ) {
				patient[i] = new Patient();
				patient[i].newPatient(arr[0].getText(), arr[1].getText(), arr[2].getText(), arr[3].getText(), arr[4].getText(), Integer.parseInt(arr[5].getText()));
				break;
			}
		}
	}
	
	private void updateMedicine(TextField[] arr) {
		for(int i=0; i<medicine.length; i++) {
			if(medicine[i] == null ) {
				medicine[i] = new Medicine();
				medicine[i].newMedicine(arr[0].getText(), arr[1].getText(), arr[2].getText(), Integer.parseInt(arr[3].getText()), Integer.parseInt(arr[4].getText()));
				break;
			}
		}
	}
	
	private void updateLab(TextField[] arr) {
		for(int i=0; i<lab.length; i++) {
			if(lab[i] == null ) {
				lab[i] = new Lab();
				lab[i].newLab(arr[0].getText(), Integer.parseInt(arr[1].getText()));
				break;
			}
		}
	}
	
	private void updateFacility(TextField[] arr) {
		for(int i=0; i<facility.length; i++) {
			if(facility[i] == null ) {
				facility[i] = new Facility();
				facility[i].newFacility(arr[0].getText());
				break;
			}
		}
	}
	
	public void setStaffs(Staff[] staffs) {
		staff = staffs;
	}
	public void setDoctors(Doctor[] doctors) {
		doctor = doctors;
	}
	public void setPatients(Patient[] patients) {
		patient = patients;
	}
	public void setMedicines(Medicine[] medicines) {
		medicine = medicines;
	}
	public void setLabs(Lab[] labs) {
		lab = labs;
	}
	public void setFacilities(Facility[] facilities) {
		facility = facilities;
	}
}
